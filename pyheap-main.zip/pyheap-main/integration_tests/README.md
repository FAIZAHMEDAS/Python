# PyHeap integration tests

## Preparation

This needs to be done only once for a Python interpreter:
```bash
poetry run pip install -e ../pyheap-ui/
```

## Running

```bash
poetry run pytest
```
